package com.servicenow.selenium;

import com.servicenow.selenium.helper.ManageBranchStaffData;
import com.servicenow.selenium.pageFactory.BranchAndStaffPage;
import com.servicenow.selenium.pageFactory.LoginPage;
import com.servicenow.selenium.pageFactory.WelcomePage;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.File;

import static org.testng.Assert.assertEquals;
import static org.testng.AssertJUnit.assertFalse;

/**
 * This test does the following:
 * Log in as admin
 * In order to create a staff, it creates a branch
 * then add a staff
 * search the staff by name to make sure new staff information has been saved
 * then edit the staff information and search again
 * finally delete it and make sure the same staff name does not appear in search result
 *
 * Created by arindam.pattanayak on 24.03.2016.
 */
public class TestAddEditDeleteStaffFeature {

    private final String TEST_HOME_PAGE = "http://localhost:8080/";
    FirefoxBinary binary = new FirefoxBinary(new File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"));
    FirefoxProfile firefoxProfile = new FirefoxProfile(new File("C:\\qa\\sample-test\\src\\test\\resources\\profile"));
    final WebDriver driver = new FirefoxDriver(binary, firefoxProfile);
    final WebDriverWait wait = new WebDriverWait(driver, 10);
    private Logger log = LoggerFactory.getLogger(TestAdminLogin.class);

    @BeforeMethod
    public void logInAsAdmin() {

        driver.get(TEST_HOME_PAGE);
        WebElement loginLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'login')]")));
        loginLink.click();
        // instantiate the login page
        LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);

        ManageBranchStaffData manageBranchStaffData = ManageBranchStaffData.getInstance();
        manageBranchStaffData.logIn(driver, loginPage, "admin", "admin");
        log.info("Successfully logged in as ADMIN");
    }

    @Test
    public void verifyStaffAddEditDeleteFunctionality() throws InterruptedException {

        ManageBranchStaffData manageBranchStaffData = ManageBranchStaffData.getInstance();

        // Create a new branch first, assuming that no branch would be present while running this test
        WelcomePage welcomePage = PageFactory.initElements(driver, WelcomePage.class);
        manageBranchStaffData.openBranchPage(welcomePage);

        BranchAndStaffPage staffPage = PageFactory.initElements(driver, BranchAndStaffPage.class);
        String branchName = RandomStringUtils.randomAlphabetic(6);
        // currently only upper case is accepted by branch code
        String branchCode = RandomStringUtils.randomAlphabetic(6).toUpperCase();
        manageBranchStaffData.addNewBranch(driver, staffPage, branchName, branchCode);
        log.info("New Branch Added");

        // Wait until the pop up is gone
        manageBranchStaffData.pause();

        // Now click on Staff Link
        manageBranchStaffData.openStaffPage(welcomePage);

        staffPage = PageFactory.initElements(driver, BranchAndStaffPage.class);
        String staffName = RandomStringUtils.randomAlphabetic(6);
        manageBranchStaffData.addNewStaff(driver, staffPage, staffName, branchName);
        log.info("New Staff Added");

        // Just to be on safe side, wait until the pop up is gone
        manageBranchStaffData.pause();

        String actualStaffName = manageBranchStaffData.searchBranchOrStaff(driver, staffPage, staffName);

        assertEquals(actualStaffName, staffName, "Created Staff Name not found");


        // Now Edit the staff and validate if its properly edited
        String newStaffName = RandomStringUtils.randomAlphabetic(6);
        String editedStaffName = manageBranchStaffData.editStaffOrBranch(driver, staffPage, newStaffName);

        assertEquals(editedStaffName, newStaffName, "Edited Staff Name not found");

        String deleteConfirmationXPath = "//div[@id='deleteStaffConfirmation']/div/div/form/div[3]/button[2]";
        Boolean isSearchResultFoundForTheDeletedStaff = manageBranchStaffData.deleteStaffOrBranch(driver,
                staffPage, newStaffName, deleteConfirmationXPath);
        assertFalse("Staff was not deleted successfully", isSearchResultFoundForTheDeletedStaff);
    }



    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
