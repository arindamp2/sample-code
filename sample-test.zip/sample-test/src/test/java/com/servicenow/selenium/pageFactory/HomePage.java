package com.servicenow.selenium.pageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage {


    @FindBy(xpath = "//a[contains(text(),'login')]")
    public WebElement loginLink;

    @FindBy(xpath = "//a[contains(text(),'Register a new account')]")
    public WebElement registerNewAccountLink;

}
