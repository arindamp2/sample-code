package com.servicenow.selenium;

import com.servicenow.selenium.helper.ManageBranchStaffData;
import com.servicenow.selenium.pageFactory.HomePage;
import com.servicenow.selenium.pageFactory.LoginPage;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import java.io.File;

import static org.testng.Assert.assertTrue;

/**
 * This test would validate if admin log in works or not
 * It checks the welcome message after logging in as admin
 * and then check the logout works or not
 * Created by arindam.pattanayak on 23.03.2016.
 */
public class TestAdminLogin {

    FirefoxBinary binary = new FirefoxBinary(new File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"));
    FirefoxProfile firefoxProfile = new FirefoxProfile(new File("C:\\qa\\sample-test\\src\\test\\resources\\profile"));
    final WebDriver driver = new FirefoxDriver(binary, firefoxProfile);
    final WebDriverWait wait = new WebDriverWait(driver, 10);
    private Logger log = LoggerFactory.getLogger(TestAdminLogin.class);


    @Test(alwaysRun = true)
    public void verifyLogin() {

        String ADMIN_USERNAME = "admin";
        String successfulLoginMessage = new StringBuilder()
                .append("You are logged in as user ")
                .append('"')
                .append(ADMIN_USERNAME)
                .append('"')
                .append('.').toString();


        String TEST_HOME_PAGE = "http://localhost:8080/";
        driver.get(TEST_HOME_PAGE);
        // Instantiate Homepage
        HomePage homePage = PageFactory.initElements(driver, HomePage.class);
        WebElement loginLink = wait.until(ExpectedConditions.elementToBeClickable(homePage.loginLink));
        loginLink.click();
        // instantiate the login page
        LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);

        ManageBranchStaffData manageBranchStaffData = ManageBranchStaffData.getInstance();
        String ADMIN_PASSWORD = "admin";
        String actualLoginMessage = manageBranchStaffData.logIn(driver, loginPage, ADMIN_USERNAME, ADMIN_PASSWORD);
        assertTrue(StringUtils.equals(actualLoginMessage, successfulLoginMessage), "Log in Unsuccessful");
        log.info("Sucessfully logged in as admin");

        // Validate logout
        loginPage.accountSection.click();
        loginPage.logout.click();
        manageBranchStaffData.pause();
        // Refresh the the home page(page factory to reload elements)
        homePage = PageFactory.initElements(driver, HomePage.class);
        assertTrue(homePage.loginLink.isEnabled(), "Logout was not successful");

    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
