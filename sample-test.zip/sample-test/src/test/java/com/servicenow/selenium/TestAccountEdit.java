package com.servicenow.selenium;

import com.servicenow.selenium.helper.ManageBranchStaffData;
import com.servicenow.selenium.pageFactory.AccountSettingsPage;
import com.servicenow.selenium.pageFactory.LoginPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.File;

import static org.testng.AssertJUnit.assertFalse;
import static org.testng.AssertJUnit.assertTrue;

/**
 * This test would log in as admin account
 * then got to account section to check if the header contains login name
 * and then try to edit the account information
 * and save it and see if it works or not
 * At the moment, this feature is broken
 * Created by arindam.pattanayak on 23.03.2016.
 */
public class TestAccountEdit {

    FirefoxBinary binary = new FirefoxBinary(new File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"));
    FirefoxProfile firefoxProfile = new FirefoxProfile(new File("C:\\qa\\sample-test\\src\\test\\resources\\profile"));
    final WebDriver driver = new FirefoxDriver(binary, firefoxProfile);
    final WebDriverWait wait = new WebDriverWait(driver, 10);
    final String USER_NAME = "admin";
    final String PASSWORD = "admin";
    private Logger log = LoggerFactory.getLogger(TestAccountEdit.class);
    ManageBranchStaffData manageBranchStaffData = ManageBranchStaffData.getInstance();


    @BeforeMethod
    public void logInAsAdmin() {

        String TEST_HOME_PAGE = "http://localhost:8080/";
        driver.get(TEST_HOME_PAGE);
        WebElement loginLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'login')]")));
        loginLink.click();
        // instantiate the login page
        LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);

        manageBranchStaffData.logIn(driver, loginPage, USER_NAME, PASSWORD);
        log.info("Successfully logged in as ADMIN");
    }
    @Test(alwaysRun = true)
    public void validateAccountEditFeature() {


        // Go to Account settings page
        LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);
        loginPage.accountSection.click();
        loginPage.settingsLink.click();
        manageBranchStaffData.pause();

        // First validate that logged information is visible
        AccountSettingsPage accountSettingsPage = PageFactory.initElements(driver, AccountSettingsPage.class);
        String header = accountSettingsPage.header.getText();
        assertTrue("login name is not visible in the account page heading", header.contains(USER_NAME));

        // Now edit user's first name and last name and try to save it
        accountSettingsPage.firstName.sendKeys("aa");
        accountSettingsPage.lastName.sendKeys("bb");
        accountSettingsPage.submitButton.click();
        manageBranchStaffData.pause();
        // Refresh the account settings page factory
        accountSettingsPage = PageFactory.initElements(driver, AccountSettingsPage.class);
        assertFalse("Account Information could not be edited, The error is : "
                + accountSettingsPage.accountUpdateFailureAlert.getText(), accountSettingsPage.accountUpdateFailureAlert.isDisplayed());

    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
