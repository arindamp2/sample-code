package com.servicenow.selenium;

import com.servicenow.selenium.helper.ManageBranchStaffData;
import com.servicenow.selenium.pageFactory.BranchAndStaffPage;
import com.servicenow.selenium.pageFactory.LoginPage;
import com.servicenow.selenium.pageFactory.WelcomePage;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.File;

import static org.testng.Assert.assertTrue;

/**
 * Created by arindam.pattanayak on 24.03.2016.
 */
public class TestPaginationInTheStaffPage {

    private final String TEST_HOME_PAGE = "http://localhost:8080/";
    FirefoxBinary binary = new FirefoxBinary(new File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"));
    FirefoxProfile firefoxProfile = new FirefoxProfile(new File("C:\\qa\\sample-test\\src\\test\\resources\\profile"));
    final WebDriver driver = new FirefoxDriver(binary, firefoxProfile);
    final WebDriverWait wait = new WebDriverWait(driver, 10);
    private Logger log = LoggerFactory.getLogger(TestAdminLogin.class);

    @BeforeMethod
    public void logInAsAdmin() {

        driver.get(TEST_HOME_PAGE);
        WebElement loginLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'login')]")));
        loginLink.click();
        // instantiate the login page
        LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);

        ManageBranchStaffData manageBranchStaffData = ManageBranchStaffData.getInstance();
        manageBranchStaffData.logIn(driver, loginPage, "admin", "admin");
        log.info("Successfully logged in as ADMIN");
    }

    @Test
    public void testPaginationInTheStaffPage() throws InterruptedException {

        ManageBranchStaffData manageBranchStaffData = ManageBranchStaffData.getInstance();

        // Create a new branch first
        // Open Branch Page
        WelcomePage welcomePage = PageFactory.initElements(driver, WelcomePage.class);
        manageBranchStaffData.openBranchPage(welcomePage);


        // Now add one branch
        BranchAndStaffPage branchPage = PageFactory.initElements(driver, BranchAndStaffPage.class);
        String branchName = RandomStringUtils.randomAlphabetic(6);
        String branchCode = RandomStringUtils.randomAlphabetic(6).toUpperCase();
        manageBranchStaffData.addNewBranch(driver, branchPage, branchName, branchCode);
        log.info("New Branch Added");

        // Wait until the pop up is gone
        manageBranchStaffData.pause();


        // Now click on Staff Link
        manageBranchStaffData.openStaffPage(welcomePage);
        // Now add 25 Staff for same branch
        for (int i = 0; i < 25; i++) {
            String staffName = RandomStringUtils.randomAlphabetic(6);
            manageBranchStaffData.addNewStaff(driver, branchPage, staffName, branchName);
            log.info("New Staff Added");
        }

        // Check if next Page Link and last Page link is present or not
        assertTrue(branchPage.nextPageLink.isEnabled(), "NextPage Link is not present");
        assertTrue(branchPage.lastPageLink.isEnabled(), "LastPage Link is not present");
        // Now click on next page and check if previous page link is clickable or not
        branchPage.nextPageLink.click();
        manageBranchStaffData.pause();
        assertTrue(branchPage.previousPageLink.isEnabled(), "NextPage Link is not present");
        assertTrue(branchPage.firstPageLink.isEnabled(), "LastPage Link is not present");
    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
